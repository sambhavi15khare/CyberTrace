-- ═══════════════════════════════════════════════════════════════════
--  schema.sql — SentinelNet AI MySQL Database Schema
-- ═══════════════════════════════════════════════════════════════════
-- Run this file once to set up the database:
--   mysql -u root -p < schema.sql
-- ═══════════════════════════════════════════════════════════════════

-- Create the database if it doesn't already exist
CREATE DATABASE IF NOT EXISTS sentinelnet
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE sentinelnet;

-- ── Main alert log table ─────────────────────────────────────────────────
-- Every detected threat is stored as one row here.
CREATE TABLE IF NOT EXISTS alert_logs (
    id              BIGINT          NOT NULL AUTO_INCREMENT,   -- unique row ID
    timestamp       DATETIME        NOT NULL,                  -- when detected (UTC)
    threat_type     VARCHAR(100)    NOT NULL,                  -- DDoS / Port Scan / etc.
    source_ip       VARCHAR(50)     NOT NULL,                  -- attacker's IP
    destination_ip  VARCHAR(50),                               -- target IP
    protocol        VARCHAR(20),                               -- TCP / UDP / ICMP
    packet_size     INT             DEFAULT 0,                 -- bytes
    threat_level    VARCHAR(20)     NOT NULL,                  -- LOW/MEDIUM/HIGH/CRITICAL
    details         TEXT,                                      -- description

    PRIMARY KEY (id),
    INDEX idx_timestamp   (timestamp),        -- fast date-range queries
    INDEX idx_source_ip   (source_ip),        -- fast IP lookups
    INDEX idx_threat_type (threat_type),      -- fast type filters
    INDEX idx_threat_level(threat_level)      -- fast level filters
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ── Sample seed data (for dashboard testing) ─────────────────────────────
-- Delete or comment these out when you have real live data.
INSERT INTO alert_logs (timestamp, threat_type, source_ip, destination_ip,
                        protocol, packet_size, threat_level, details) VALUES
('2024-06-01 10:00:00', 'DDoS',        '192.168.1.100', '10.0.0.1', 'UDP',  512,  'CRITICAL', 'IP 192.168.1.100 sent 150 packets in 5s'),
('2024-06-01 10:01:15', 'Port Scan',   '10.0.0.99',     '10.0.0.1', 'TCP',  64,   'HIGH',     'IP 10.0.0.99 scanned 50 ports'),
('2024-06-01 10:02:30', 'Packet Flood','Multiple',       '10.0.0.1', 'Mixed',0,    'HIGH',     'Total 600 packets in 5s'),
('2024-06-01 10:05:00', 'DDoS',        '172.16.0.55',   '10.0.0.1', 'TCP',  1024, 'CRITICAL', 'IP 172.16.0.55 sent 200 packets in 5s'),
('2024-06-01 10:07:45', 'Port Scan',   '192.168.1.200', '10.0.0.1', 'TCP',  48,   'MEDIUM',   'IP 192.168.1.200 scanned 25 ports');


-- ── Useful view: recent critical threats ─────────────────────────────────
CREATE OR REPLACE VIEW critical_alerts AS
    SELECT id, timestamp, threat_type, source_ip, threat_level, details
    FROM alert_logs
    WHERE threat_level IN ('CRITICAL', 'HIGH')
    ORDER BY timestamp DESC
    LIMIT 100;
