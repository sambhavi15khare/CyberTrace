package com.sentinelnet.controller;

// ══════════════════════════════════════════════════════════════════════
//  AlertLogController.java — REST Controller (API Layer)
// ══════════════════════════════════════════════════════════════════════
// Exposes HTTP endpoints that the Flask API and Dashboard call.
//
//  POST   /api/alerts              → save a new alert
//  GET    /api/alerts              → list all alerts
//  GET    /api/alerts/{id}         → get one alert by ID
//  GET    /api/alerts/level/{lvl}  → filter by threat level
//  GET    /api/alerts/ip/{ip}      → filter by source IP
//  GET    /api/alerts/stats        → dashboard stats
//  DELETE /api/alerts/{id}         → delete an alert

import com.sentinelnet.dto.AlertLogDTO;
import com.sentinelnet.entity.AlertLog;
import com.sentinelnet.service.AlertLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController                       // marks as REST API (auto JSON responses)
@RequestMapping("/api/alerts")        // base URL for all endpoints
@CrossOrigin(origins = "*")           // allow CORS from dashboard / Flask
public class AlertLogController {

    @Autowired
    private AlertLogService service;


    // ── POST /api/alerts ──────────────────────────────────────────────
    // Flask API sends alert JSON here → saved to MySQL
    @PostMapping
    public ResponseEntity<AlertLog> createAlert(@RequestBody AlertLogDTO dto) {
        AlertLog saved = service.saveAlert(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }


    // ── GET /api/alerts ───────────────────────────────────────────────
    // Returns all alerts (dashboard main table)
    @GetMapping
    public ResponseEntity<List<AlertLog>> getAllAlerts() {
        return ResponseEntity.ok(service.getAllAlerts());
    }


    // ── GET /api/alerts/level/{level} ─────────────────────────────────
    // Filter by threat level: CRITICAL, HIGH, MEDIUM, LOW
    @GetMapping("/level/{level}")
    public ResponseEntity<List<AlertLog>> getByLevel(@PathVariable String level) {
        return ResponseEntity.ok(service.getAlertsByLevel(level));
    }


    // ── GET /api/alerts/ip/{sourceIp} ────────────────────────────────
    // Filter by attacker's source IP
    @GetMapping("/ip/{sourceIp}")
    public ResponseEntity<List<AlertLog>> getByIp(@PathVariable String sourceIp) {
        return ResponseEntity.ok(service.getAlertsBySourceIp(sourceIp));
    }


    // ── GET /api/alerts/stats ─────────────────────────────────────────
    // Dashboard stats: total, by level, by type
    @GetMapping("/stats")
    public ResponseEntity<Map<String, Long>> getStats() {
        return ResponseEntity.ok(service.getStats());
    }


    // ── DELETE /api/alerts/{id} ───────────────────────────────────────
    // Remove a single alert record
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteAlert(@PathVariable Long id) {
        boolean deleted = service.deleteAlert(id);
        if (deleted) {
            return ResponseEntity.ok("Alert " + id + " deleted.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                                 .body("Alert " + id + " not found.");
        }
    }
}
