package com.sentinelnet.entity;

// ══════════════════════════════════════════════════════════════════════
//  AlertLog.java — JPA Entity (maps to the `alert_logs` MySQL table)
// ══════════════════════════════════════════════════════════════════════
// Each AlertLog object = one row in the database.
// Lombok annotations generate getters/setters/constructors automatically.

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity                         // Marks this class as a DB table
@Table(name = "alert_logs")     // Exact table name in MySQL
@Data                           // Lombok: generates getters + setters
@NoArgsConstructor              // Lombok: no-arg constructor (required by JPA)
@AllArgsConstructor             // Lombok: all-arg constructor
@Builder                        // Lombok: builder pattern (nice for creating objects)
public class AlertLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // AUTO_INCREMENT in MySQL
    private Long id;

    @Column(name = "timestamp", nullable = false)
    private LocalDateTime timestamp;

    @Column(name = "threat_type", nullable = false, length = 100)
    private String threatType;        // e.g. "DDoS", "Port Scan"

    @Column(name = "source_ip", nullable = false, length = 50)
    private String sourceIp;

    @Column(name = "destination_ip", length = 50)
    private String destinationIp;

    @Column(name = "protocol", length = 20)
    private String protocol;          // TCP / UDP / ICMP

    @Column(name = "packet_size")
    private Integer packetSize;

    @Column(name = "threat_level", nullable = false, length = 20)
    private String threatLevel;       // LOW / MEDIUM / HIGH / CRITICAL

    @Column(name = "details", columnDefinition = "TEXT")
    private String details;           // free-text description of the alert
}
