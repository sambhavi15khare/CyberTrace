package com.sentinelnet.repository;

// ══════════════════════════════════════════════════════════════════════
//  AlertLogRepository.java — Spring Data JPA Repository
// ══════════════════════════════════════════════════════════════════════
// Spring auto-generates the SQL queries; we just declare method signatures.
// No implementation class needed!

import com.sentinelnet.entity.AlertLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository  // Marks this as a Spring-managed DB component
public interface AlertLogRepository extends JpaRepository<AlertLog, Long> {

    // Spring converts method names → SQL automatically:

    // SELECT * FROM alert_logs WHERE threat_level = ? ORDER BY timestamp DESC
    List<AlertLog> findByThreatLevelOrderByTimestampDesc(String threatLevel);

    // SELECT * FROM alert_logs WHERE threat_type = ?
    List<AlertLog> findByThreatType(String threatType);

    // SELECT * FROM alert_logs WHERE source_ip = ? ORDER BY timestamp DESC
    List<AlertLog> findBySourceIpOrderByTimestampDesc(String sourceIp);

    // COUNT(*) by threat type (useful for dashboard stats)
    long countByThreatType(String threatType);

    // COUNT(*) by threat level
    long countByThreatLevel(String threatLevel);
}
