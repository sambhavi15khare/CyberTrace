package com.sentinelnet;

// ══════════════════════════════════════════════════════════════════
//  SentinelNetApplication.java — Spring Boot Entry Point
// ══════════════════════════════════════════════════════════════════
// Run this class to start the Java backend.
//
//  From IDE  : right-click → Run
//  From CLI  : mvn spring-boot:run
//              OR  java -jar target/sentinelnet-backend-1.0.0.jar

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication   // = @Configuration + @EnableAutoConfiguration + @ComponentScan
public class SentinelNetApplication {

    public static void main(String[] args) {
        System.out.println("""
            ╔══════════════════════════════════════════╗
            ║   SentinelNet AI  —  Java Backend v1.0  ║
            ║   http://localhost:8080/api/alerts       ║
            ╚══════════════════════════════════════════╝
            """);
        SpringApplication.run(SentinelNetApplication.class, args);
    }
}
