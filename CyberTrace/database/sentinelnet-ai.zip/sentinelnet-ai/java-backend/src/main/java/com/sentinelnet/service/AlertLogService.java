package com.sentinelnet.service;

// ══════════════════════════════════════════════════════════════════════
//  AlertLogService.java — Service Layer (Business Logic)
// ══════════════════════════════════════════════════════════════════════
// The controller calls this service; the service calls the repository.
// Keeps controller thin and logic testable in isolation.

import com.sentinelnet.dto.AlertLogDTO;
import com.sentinelnet.entity.AlertLog;
import com.sentinelnet.repository.AlertLogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Map;

@Service  // Marks this as a Spring-managed service
public class AlertLogService {

    // Spring injects the repository automatically (@Autowired)
    @Autowired
    private AlertLogRepository repository;

    // Date format expected from the Python Flask API
    private static final DateTimeFormatter ISO_FMT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");


    /**
     * Convert a DTO (JSON from Flask) → entity → save to MySQL.
     * Returns the saved entity with its auto-generated ID.
     */
    public AlertLog saveAlert(AlertLogDTO dto) {

        // Parse timestamp string → LocalDateTime
        LocalDateTime parsedTime;
        try {
            parsedTime = LocalDateTime.parse(dto.getTimestamp(), ISO_FMT);
        } catch (DateTimeParseException | NullPointerException e) {
            parsedTime = LocalDateTime.now();  // fallback to now
        }

        // Build entity using Lombok's @Builder
        AlertLog alert = AlertLog.builder()
                .timestamp(parsedTime)
                .threatType(dto.getThreatType())
                .sourceIp(dto.getSourceIp())
                .destinationIp(dto.getDestinationIp())
                .protocol(dto.getProtocol())
                .packetSize(dto.getPacketSize())
                .threatLevel(dto.getThreatLevel())
                .details(dto.getDetails())
                .build();

        return repository.save(alert);   // INSERT INTO alert_logs ...
    }


    /** Return all alerts, newest first. */
    public List<AlertLog> getAllAlerts() {
        return repository.findAll();
    }


    /** Return alerts by threat level (e.g. "CRITICAL"). */
    public List<AlertLog> getAlertsByLevel(String level) {
        return repository.findByThreatLevelOrderByTimestampDesc(level.toUpperCase());
    }


    /** Return alerts by source IP. */
    public List<AlertLog> getAlertsBySourceIp(String ip) {
        return repository.findBySourceIpOrderByTimestampDesc(ip);
    }


    /**
     * Return a stats map for the dashboard.
     * { "total": 42, "critical": 5, "high": 12, "ddos": 3, ... }
     */
    public Map<String, Long> getStats() {
        return Map.of(
                "total",    repository.count(),
                "critical", repository.countByThreatLevel("CRITICAL"),
                "high",     repository.countByThreatLevel("HIGH"),
                "medium",   repository.countByThreatLevel("MEDIUM"),
                "low",      repository.countByThreatLevel("LOW"),
                "ddos",     repository.countByThreatType("DDoS"),
                "portScan", repository.countByThreatType("Port Scan"),
                "flood",    repository.countByThreatType("Packet Flood")
        );
    }


    /** Delete a single alert by ID (admin use). */
    public boolean deleteAlert(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return true;
        }
        return false;
    }
}
