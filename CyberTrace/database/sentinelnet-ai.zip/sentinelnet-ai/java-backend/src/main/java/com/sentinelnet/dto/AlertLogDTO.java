package com.sentinelnet.dto;

// ══════════════════════════════════════════════════════════════
//  AlertLogDTO.java — Data Transfer Object
// ══════════════════════════════════════════════════════════════
// The controller receives JSON in this shape from the Flask API.
// Using a DTO keeps our internal entity separate from API contracts.

import lombok.*;

@Data               // Lombok: getters + setters
@NoArgsConstructor
@AllArgsConstructor
public class AlertLogDTO {

    private String timestamp;        // ISO-8601 string e.g. "2024-01-15T10:30:00Z"
    private String threatType;       // e.g. "DDoS"
    private String sourceIp;         // attacking IP
    private String destinationIp;    // target IP
    private String protocol;         // TCP / UDP / ICMP
    private Integer packetSize;      // bytes
    private String threatLevel;      // LOW / MEDIUM / HIGH / CRITICAL
    private String details;          // description
}
