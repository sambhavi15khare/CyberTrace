# SentinelNet AI 🛡️
### Real-Time Network Intrusion Detection & Threat Monitoring System
*College Minor Project — 4-Member Team*

---

## 📁 Complete Project Structure

```
sentinelnet-ai/
│
├── python-agent/                   ← Member 1 & 2
│   ├── main.py                     ← Entry point (runs everything)
│   ├── requirements.txt
│   │
│   ├── sniffer/
│   │   └── sniffer.py              ← Packet capture (Member 1)
│   │
│   ├── detector/
│   │   └── detector.py             ← Threat detection (Member 2)
│   │
│   ├── api/
│   │   └── api.py                  ← Flask REST API bridge
│   │
│   └── utils/
│       └── utils.py                ← Shared helpers
│
├── java-backend/                   ← Member 3
│   ├── pom.xml
│   └── src/main/
│       ├── java/com/sentinelnet/
│       │   ├── SentinelNetApplication.java
│       │   ├── controller/
│       │   │   └── AlertLogController.java
│       │   ├── service/
│       │   │   └── AlertLogService.java
│       │   ├── repository/
│       │   │   └── AlertLogRepository.java
│       │   ├── entity/
│       │   │   └── AlertLog.java
│       │   └── dto/
│       │       └── AlertLogDTO.java
│       └── resources/
│           └── application.properties
│
├── database/
│   └── schema.sql                  ← MySQL schema + seed data
│
├── frontend/                       ← Member 4
│   ├── index.html
│   ├── style.css
│   └── script.js
│
└── README.md
```

---

## 🔄 System Architecture & Data Flow

```
[Network Traffic]
      │
      ▼
[sniffer.py]  ←── Scapy raw socket capture
      │  PACKET_BUFFER (shared deque)
      ▼
[detector.py] ←── Rule-based analysis every 3s
      │  HTTP POST alert JSON
      ▼
[api.py]      ←── Flask API on :5000
      │  POST /api/alerts
      ▼
[Spring Boot]  ←── Java backend on :8080
      │  JPA save()
      ▼
[MySQL]        ←── sentinelnet.alert_logs table
      ▲
      │  GET /api/alerts
[script.js]   ←── Dashboard polls Flask every 10s
      │
[index.html]  ←── Browser renders live dashboard
```

---

## 👥 Team Division

| Member | Owns | Files |
|--------|------|-------|
| 1 | Packet Sniffer | `sniffer/sniffer.py` |
| 2 | Detection Engine | `detector/detector.py` |
| 3 | Java Backend + Database | `java-backend/`, `database/schema.sql` |
| 4 | Dashboard Frontend | `frontend/` |

---

## ⚙️ Prerequisites

| Tool | Version | Download |
|------|---------|----------|
| Python | 3.10+ | python.org |
| Java JDK | 17+ | adoptium.net |
| Maven | 3.8+ | maven.apache.org |
| MySQL | 8.0+ | mysql.com |
| Git | any | git-scm.com |

---

## 🚀 Installation & Setup

### Step 1 — Clone the Project
```bash
git clone https://github.com/your-team/sentinelnet-ai.git
cd sentinelnet-ai
```

### Step 2 — Set Up MySQL Database
```bash
# Log in to MySQL
mysql -u root -p

# Run the schema script
source database/schema.sql;

# Verify
USE sentinelnet;
SHOW TABLES;
SELECT * FROM alert_logs;
```

### Step 3 — Configure Java Backend
Edit `java-backend/src/main/resources/application.properties`:
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/sentinelnet?...
spring.datasource.username=root
spring.datasource.password=YOUR_MYSQL_PASSWORD   ← change this
```

### Step 4 — Install Python Dependencies
```bash
cd python-agent
pip install -r requirements.txt
```

> **Windows users:** You may need `pip install scapy` separately and run as Administrator.

---

## ▶️ Running the Project

Open **4 terminal windows** (one per component):

### Terminal 1 — Java Backend
```bash
cd java-backend
mvn spring-boot:run
```
✅ Ready when you see: `Started SentinelNetApplication on port 8080`

### Terminal 2 — Python Agent (Flask + Sniffer + Detector)
```bash
# Linux / macOS (requires root for packet capture)
cd python-agent
sudo python main.py

# Windows — run Command Prompt as Administrator:
python main.py

# To skip live capture (testing only):
NO_SNIFF=1 python main.py
```
✅ Ready when you see: `SentinelNet Flask API` banner and `Starting Flask API on :5000`

### Terminal 3 — Dashboard
```bash
# Option A: Python simple server (no install needed)
cd frontend
python -m http.server 3000
# Open: http://localhost:3000

# Option B: Just open index.html directly in a browser
#  (CORS might block API calls — Option A is safer)
```
✅ Open `http://localhost:3000` in your browser.

### Terminal 4 — Optional: simulate alerts without live capture
```bash
cd python-agent
python detector/detector.py
```
This runs the simulated test (150-packet DDoS + 50-port scan) and
sends fake alerts through the full pipeline.

---

## 🧪 Testing Instructions

### 1. Test MySQL
```sql
USE sentinelnet;
SELECT COUNT(*) FROM alert_logs;               -- should be ≥ 5 (seed data)
SELECT * FROM critical_alerts LIMIT 5;
```

### 2. Test Java API (curl)
```bash
# List all alerts
curl http://localhost:8080/api/alerts

# Create a test alert
curl -X POST http://localhost:8080/api/alerts \
  -H "Content-Type: application/json" \
  -d '{
    "timestamp": "2024-06-01T12:00:00Z",
    "threatType": "DDoS",
    "sourceIp": "1.2.3.4",
    "destinationIp": "10.0.0.1",
    "protocol": "UDP",
    "packetSize": 512,
    "threatLevel": "CRITICAL",
    "details": "Manual test alert"
  }'

# Stats
curl http://localhost:8080/api/alerts/stats

# Filter by level
curl http://localhost:8080/api/alerts/level/CRITICAL
```

### 3. Test Flask API
```bash
# Health check
curl http://localhost:5000/health

# Send a test alert through Flask
curl -X POST http://localhost:5000/alert \
  -H "Content-Type: application/json" \
  -d '{
    "timestamp": "2024-06-01T12:00:00Z",
    "threat_type": "Port Scan",
    "source_ip": "192.168.99.1",
    "destination_ip": "10.0.0.1",
    "protocol": "TCP",
    "packet_size": 64,
    "threat_level": "HIGH",
    "details": "Flask test alert"
  }'

# Get all alerts via Flask
curl http://localhost:5000/alerts

# Stats
curl http://localhost:5000/alerts/stats
```

### 4. Test Detector (no root needed)
```bash
cd python-agent
python detector/detector.py
# Expected output: 2+ alerts detected
```

### 5. Test Sniffer (root required)
```bash
cd python-agent
sudo python sniffer/sniffer.py
# Should print parsed packet dicts for 20 packets
```

### 6. Test Dashboard
1. Open `http://localhost:3000`
2. Stat cards should show numbers from seed data
3. Bar chart should show DDoS, Port Scan, Packet Flood bars
4. Alert table should list 5 seed rows
5. Click "REFRESH" — counters should stay stable
6. Send a curl POST to Flask → dashboard auto-updates in 10s

---

## 🔌 API Quick Reference

### Flask API (port 5000)
| Method | URL | Description |
|--------|-----|-------------|
| GET | `/health` | Liveness check |
| POST | `/alert` | Receive alert from detector |
| GET | `/alerts?limit=N` | Get last N alerts |
| GET | `/alerts/stats` | Threat statistics |

### Java API (port 8080)
| Method | URL | Description |
|--------|-----|-------------|
| POST | `/api/alerts` | Save new alert |
| GET | `/api/alerts` | All alerts |
| GET | `/api/alerts/level/{level}` | Filter by severity |
| GET | `/api/alerts/ip/{ip}` | Filter by source IP |
| GET | `/api/alerts/stats` | Dashboard stats |
| DELETE | `/api/alerts/{id}` | Delete alert |

---

## 🔧 Common Issues

| Problem | Fix |
|---------|-----|
| `Permission denied` in sniffer | Run as sudo (Linux/Mac) or Administrator (Windows) |
| `scapy.error: No route to host` | Try setting `IFACE=lo` for loopback interface |
| Java won't start | Check MySQL is running; verify password in `application.properties` |
| Dashboard shows no data | Use seed data: `source database/schema.sql` — or check Flask is running |
| CORS errors in browser | Use `python -m http.server 3000` instead of file:// |

---

## 📈 Future Improvements

1. **ML Detection** — Replace rule-based thresholds with a trained Scikit-learn model (RandomForest / IsolationForest)
2. **WebSocket push** — Dashboard receives real-time alerts via WebSocket instead of polling
3. **Email / Telegram alerts** — Notify admin when CRITICAL threats are found
4. **User authentication** — Login page for the dashboard
5. **GeoIP mapping** — Map source IPs to countries on a world map
6. **Docker Compose** — One `docker-compose up` to start all services
7. **Packet replay** — Feed `.pcap` files through the detector for testing
