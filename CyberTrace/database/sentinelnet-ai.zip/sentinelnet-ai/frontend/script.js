/**
 * script.js — SentinelNet AI Dashboard Logic
 * ============================================
 * TEAM MEMBER 4 — owns this file.
 *
 * Fetches alert data from the Flask API (localhost:5000) and renders:
 *   • stat cards (counts by severity)
 *   • bar chart (by threat type)
 *   • live feed (latest alerts, newest first)
 *   • full alert table (filterable)
 *
 * Auto-refreshes every 10 seconds.
 */

// ── Config ───────────────────────────────────────────────────────
// Change FLASK_BASE if Flask is running on a different host/port.
const FLASK_BASE   = "http://localhost:5000";
const JAVA_BASE    = "http://localhost:8080/api";
const POLL_INTERVAL = 10_000;   // ms between auto-refreshes

// ── State ────────────────────────────────────────────────────────
let allAlerts   = [];         // all fetched alerts
let filterLevel = "ALL";      // current severity filter

// Bar chart colour palette (index-matched to threat types array below)
const BAR_COLOURS = ["#ff2d55", "#ff6b35", "#ffcc00", "#00d4ff", "#00ff87", "#bf5fff"];


// ── Initialise ───────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  startClock();
  fetchAll();
  setInterval(fetchAll, POLL_INTERVAL);
});


// ── Clock & Date ─────────────────────────────────────────────────
function startClock() {
  function tick() {
    const now = new Date();
    document.getElementById("clock").textContent = now.toLocaleTimeString("en-GB");
    document.getElementById("date-display").textContent =
      now.toLocaleDateString("en-GB", { day:"2-digit", month:"short", year:"numeric" });
  }
  tick();
  setInterval(tick, 1000);
}


// ── Data Fetching ─────────────────────────────────────────────────
async function fetchAll() {
  await Promise.all([fetchAlerts(), fetchStats()]);
}

async function fetchAlerts() {
  try {
    const res  = await fetch(`${FLASK_BASE}/alerts?limit=200`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    allAlerts = await res.json();

    renderTable(allAlerts);
    renderLiveFeed(allAlerts);
    setStatus("LIVE", true);
  } catch (err) {
    console.warn("Flask alerts unavailable, trying Java backend…", err);
    await fetchAlertsFromJava();
  }
}

async function fetchAlertsFromJava() {
  try {
    const res = await fetch(`${JAVA_BASE}/alerts`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    // Java returns camelCase keys; normalise them
    const raw = await res.json();
    allAlerts = raw.map(normaliseJavaAlert);

    renderTable(allAlerts);
    renderLiveFeed(allAlerts);
    setStatus("JAVA", true);
  } catch (err) {
    console.error("Both backends unreachable:", err);
    setStatus("OFFLINE", false);
    useSampleData();   // show sample data so dashboard isn't empty
  }
}

async function fetchStats() {
  try {
    // Try Flask stats endpoint first
    const res  = await fetch(`${FLASK_BASE}/alerts/stats`);
    const data = await res.json();

    setCard("stat-critical", data.by_level?.CRITICAL || 0);
    setCard("stat-high",     data.by_level?.HIGH     || 0);
    setCard("stat-medium",   data.by_level?.MEDIUM   || 0);
    setCard("stat-total",    data.total               || 0);
    renderBarChart(data.by_threat || {});
  } catch {
    // Derive stats from allAlerts if API unavailable
    deriveStatsFromAlerts();
  }
}


// ── Helpers ──────────────────────────────────────────────────────
function normaliseJavaAlert(a) {
  // Java uses camelCase; normalise to snake_case used by Python alerts
  return {
    timestamp:      a.timestamp,
    threat_type:    a.threatType,
    source_ip:      a.sourceIp,
    destination_ip: a.destinationIp,
    protocol:       a.protocol,
    packet_size:    a.packetSize,
    threat_level:   a.threatLevel,
    details:        a.details,
  };
}

function deriveStatsFromAlerts() {
  const byLevel = {}, byThreat = {};
  allAlerts.forEach(a => {
    const l = a.threat_level || "Unknown";
    const t = a.threat_type  || "Unknown";
    byLevel[l]  = (byLevel[l]  || 0) + 1;
    byThreat[t] = (byThreat[t] || 0) + 1;
  });
  setCard("stat-critical", byLevel.CRITICAL || 0);
  setCard("stat-high",     byLevel.HIGH     || 0);
  setCard("stat-medium",   byLevel.MEDIUM   || 0);
  setCard("stat-total",    allAlerts.length);
  renderBarChart(byThreat);
}

function setCard(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

function setStatus(label, ok) {
  const pill = document.getElementById("status-pill");
  const txt  = document.getElementById("status-text");
  txt.textContent = label;
  pill.style.borderColor = ok ? "var(--green-muted)" : "var(--red)";
  pill.querySelector(".status-dot").style.background = ok ? "var(--green)" : "var(--red)";
}


// ── Bar Chart ─────────────────────────────────────────────────────
function renderBarChart(byThreat) {
  const container = document.getElementById("bar-chart");
  if (!container) return;

  const entries = Object.entries(byThreat).sort((a, b) => b[1] - a[1]);
  const max     = Math.max(...entries.map(e => e[1]), 1);

  container.innerHTML = entries.map(([label, count], i) => {
    const pct   = Math.round((count / max) * 100);
    const color = BAR_COLOURS[i % BAR_COLOURS.length];
    return `
      <div class="bar-item">
        <span class="bar-label">${label}</span>
        <div class="bar-track">
          <div class="bar-fill" style="width:${pct}%; background:${color};"></div>
        </div>
        <span class="bar-count">${count}</span>
      </div>`;
  }).join("");

  if (!entries.length) {
    container.innerHTML = `<p style="color:var(--text-dim);font-size:12px;">No data yet.</p>`;
  }
}


// ── Live Feed ─────────────────────────────────────────────────────
function renderLiveFeed(alerts) {
  const feed = document.getElementById("live-feed");
  if (!feed) return;

  // Show the 15 most recent, newest first
  const recent = [...alerts].reverse().slice(0, 15);

  if (!recent.length) {
    feed.innerHTML = `<div class="feed-placeholder">Waiting for threats…</div>`;
    return;
  }

  feed.innerHTML = recent.map(a => {
    const level = a.threat_level || "LOW";
    const ts    = formatTimestamp(a.timestamp);
    return `
      <div class="feed-entry ${level}">
        <span class="feed-time">${ts}</span>
        &nbsp;
        <span class="feed-type">[${a.threat_type || "?"}]</span>
        &nbsp;
        ${a.source_ip || "?"}
        →
        ${a.destination_ip || "*"}
        &nbsp;&nbsp;
        <em style="color:var(--text-secondary)">${truncate(a.details || "", 60)}</em>
      </div>`;
  }).join("");
}


// ── Alert Table ───────────────────────────────────────────────────
function applyFilter() {
  filterLevel = document.getElementById("filter-level").value;
  renderTable(allAlerts);
}

function renderTable(alerts) {
  const tbody = document.getElementById("alert-tbody");
  if (!tbody) return;

  const filtered = filterLevel === "ALL"
    ? alerts
    : alerts.filter(a => (a.threat_level || "").toUpperCase() === filterLevel);

  if (!filtered.length) {
    tbody.innerHTML = `<tr><td colspan="9" class="empty-msg">No alerts match the current filter.</td></tr>`;
    return;
  }

  // Show newest first, limit 100 rows
  const rows = [...filtered].reverse().slice(0, 100);

  tbody.innerHTML = rows.map((a, idx) => {
    const level = (a.threat_level || "LOW").toUpperCase();
    return `
      <tr>
        <td style="color:var(--text-dim)">${idx + 1}</td>
        <td style="color:var(--text-secondary)">${formatTimestamp(a.timestamp)}</td>
        <td>${a.threat_type || "—"}</td>
        <td style="color:var(--green)">${a.source_ip || "—"}</td>
        <td>${a.destination_ip || "—"}</td>
        <td>${a.protocol || "—"}</td>
        <td>${a.packet_size != null ? a.packet_size + "B" : "—"}</td>
        <td><span class="badge badge-${level}">${level}</span></td>
        <td title="${a.details || ""}">${truncate(a.details || "—", 50)}</td>
      </tr>`;
  }).join("");
}


// ── Sample / Fallback Data ────────────────────────────────────────
function useSampleData() {
  const sample = [
    { timestamp:"2024-06-01T10:00:00Z", threat_type:"DDoS",        source_ip:"192.168.1.100", destination_ip:"10.0.0.1", protocol:"UDP",  packet_size:512,  threat_level:"CRITICAL", details:"IP sent 150 packets in 5s" },
    { timestamp:"2024-06-01T10:01:15Z", threat_type:"Port Scan",   source_ip:"10.0.0.99",     destination_ip:"10.0.0.1", protocol:"TCP",  packet_size:64,   threat_level:"HIGH",     details:"50 ports scanned" },
    { timestamp:"2024-06-01T10:02:30Z", threat_type:"Packet Flood",source_ip:"Multiple",       destination_ip:"10.0.0.1", protocol:"Mixed",packet_size:0,    threat_level:"HIGH",     details:"600 packets in 5s" },
    { timestamp:"2024-06-01T10:05:00Z", threat_type:"DDoS",        source_ip:"172.16.0.55",   destination_ip:"10.0.0.1", protocol:"TCP",  packet_size:1024, threat_level:"CRITICAL", details:"200 packets in 5s" },
    { timestamp:"2024-06-01T10:07:45Z", threat_type:"Port Scan",   source_ip:"192.168.1.200", destination_ip:"10.0.0.1", protocol:"TCP",  packet_size:48,   threat_level:"MEDIUM",   details:"25 ports scanned" },
  ];
  allAlerts = sample;
  renderTable(sample);
  renderLiveFeed(sample);
  deriveStatsFromAlerts();
}


// ── String Helpers ────────────────────────────────────────────────
function truncate(str, max) {
  return str.length > max ? str.slice(0, max) + "…" : str;
}

function formatTimestamp(ts) {
  if (!ts) return "—";
  try {
    return new Date(ts).toLocaleString("en-GB", {
      day:"2-digit", month:"short", hour:"2-digit", minute:"2-digit", second:"2-digit"
    });
  } catch {
    return ts;
  }
}
