"""
api.py — Flask REST API Bridge
================================
Sits between the Python detection engine and the Java Spring Boot backend.

Endpoints
---------
POST /alert          Receive an alert from detector.py → forward to Java
GET  /alerts         Return locally cached alerts (for dashboard fallback)
GET  /health         Quick liveness check

This module also stores alerts in an in-memory list so the dashboard
can still work even if the Java backend is temporarily down.

HOW TO RUN:
  python api.py
  (No root needed — just make sure Java backend is also running)
"""

import requests
from flask import Flask, request, jsonify
from flask_cors import CORS

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from utils.utils import logger, save_alert_to_file, load_alerts_from_file

# ── App setup ─────────────────────────────────────────────────────────────
app = Flask(__name__)
CORS(app)   # allow the HTML dashboard to call this API from any origin

# ── Java backend URL ───────────────────────────────────────────────────────
JAVA_BACKEND_URL = "http://localhost:8080/api/alerts"

# ── In-memory cache (fallback when Java is down) ──────────────────────────
_alert_cache: list = []


# ── Helper: forward alert to Java backend ─────────────────────────────────
def _forward_to_java(alert: dict) -> bool:
    """
    POST the alert dict to the Spring Boot backend.
    Returns True on success, False on failure.
    """
    try:
        resp = requests.post(JAVA_BACKEND_URL, json=alert, timeout=3)
        return resp.status_code in (200, 201)
    except Exception as e:
        logger.warning(f"[Flask API] Could not reach Java backend: {e}")
        return False


# ── Routes ────────────────────────────────────────────────────────────────

@app.route("/health", methods=["GET"])
def health():
    """Liveness probe — returns 200 OK with status info."""
    return jsonify({"status": "ok", "service": "SentinelNet Flask API"}), 200


@app.route("/alert", methods=["POST"])
def receive_alert():
    """
    Accept a JSON alert from detector.py.

    Expected body:
    {
      "timestamp": "...",
      "threat_type": "DDoS",
      "source_ip": "1.2.3.4",
      "destination_ip": "5.6.7.8",
      "protocol": "TCP",
      "packet_size": 512,
      "threat_level": "CRITICAL",
      "details": "..."
    }
    """
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "Invalid JSON body"}), 400

    # 1. Cache locally
    _alert_cache.append(data)
    save_alert_to_file(data)

    # 2. Try forwarding to Java (best-effort)
    forwarded = _forward_to_java(data)
    logger.info(f"[Flask API] Alert received | forwarded={forwarded} | type={data.get('threat_type')}")

    return jsonify({
        "message": "Alert received",
        "forwarded_to_java": forwarded,
        "alert": data,
    }), 201


@app.route("/alerts", methods=["GET"])
def get_alerts():
    """
    Return all alerts.
    First tries the Java backend; falls back to local cache.
    Supports ?limit=N query param (default 50).
    """
    limit = request.args.get("limit", 50, type=int)

    # Try fetching from Java backend first
    try:
        resp = requests.get(JAVA_BACKEND_URL, timeout=3)
        if resp.status_code == 200:
            java_alerts = resp.json()
            return jsonify(java_alerts[-limit:]), 200
    except Exception:
        logger.warning("[Flask API] Java backend unreachable — returning local cache.")

    # Fallback: local cache
    cached = load_alerts_from_file()
    return jsonify(cached[-limit:]), 200


@app.route("/alerts/stats", methods=["GET"])
def get_stats():
    """
    Return simple aggregate stats for the dashboard.
    {
      "total": 42,
      "by_threat": {"DDoS": 5, "Port Scan": 12, ...},
      "by_level":  {"CRITICAL": 2, "HIGH": 8, ...}
    }
    """
    alerts = load_alerts_from_file()

    by_threat: dict = {}
    by_level: dict = {}

    for a in alerts:
        t = a.get("threat_type", "Unknown")
        l = a.get("threat_level", "Unknown")
        by_threat[t] = by_threat.get(t, 0) + 1
        by_level[l] = by_level.get(l, 0) + 1

    return jsonify({
        "total": len(alerts),
        "by_threat": by_threat,
        "by_level": by_level,
    }), 200


# ── Entry point ───────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("╔══════════════════════════════════╗")
    print("║   SentinelNet Flask API v1.0     ║")
    print("║   http://localhost:5000          ║")
    print("╚══════════════════════════════════╝\n")
    app.run(host="0.0.0.0", port=5000, debug=True)
