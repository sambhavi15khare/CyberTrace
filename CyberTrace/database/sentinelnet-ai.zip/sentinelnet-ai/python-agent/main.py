"""
main.py — Python Agent Entry Point
=====================================
Starts both the sniffer (background thread) and the detection loop,
plus the Flask API server — all in one command.

HOW TO RUN:
  sudo python main.py              # Linux/macOS (root for raw sockets)
  # Windows: run as Administrator

  Optional env vars:
    IFACE=eth0   — network interface to sniff on
    NO_SNIFF=1   — skip live capture (useful for testing detection logic only)
"""

import os
import sys
import threading

# ── Adjust import paths ────────────────────────────────────────────────────
BASE = os.path.dirname(__file__)
sys.path.insert(0, BASE)

from utils.utils import logger

# ── Detect run mode ────────────────────────────────────────────────────────
NO_SNIFF = os.environ.get("NO_SNIFF", "0") == "1"
IFACE    = os.environ.get("IFACE", None)          # e.g. "eth0" or "Wi-Fi"


def start_flask():
    """Run Flask API (blocks — runs in its own thread)."""
    from api.api import app
    logger.info("[Main] Starting Flask API on :5000")
    app.run(host="0.0.0.0", port=5000, debug=False, use_reloader=False)


def start_sniffer():
    """Start packet capture (blocks — runs in its own thread)."""
    from sniffer.sniffer import start_sniffing
    logger.info(f"[Main] Starting packet sniffer on iface={IFACE or 'auto'}")
    start_sniffing(interface=IFACE)


def start_detector():
    """Start the detection loop (blocks — runs in its own thread)."""
    from detector.detector import start_detection_loop
    from sniffer.sniffer import get_recent_packets
    logger.info("[Main] Starting detection engine")
    start_detection_loop(get_packets_fn=get_recent_packets, interval=3.0)


if __name__ == "__main__":
    print("""
 ███████╗███████╗███╗   ██╗████████╗██╗███╗   ██╗███████╗██╗     
 ██╔════╝██╔════╝████╗  ██║╚══██╔══╝██║████╗  ██║██╔════╝██║     
 ███████╗█████╗  ██╔██╗ ██║   ██║   ██║██╔██╗ ██║█████╗  ██║     
 ╚════██║██╔══╝  ██║╚██╗██║   ██║   ██║██║╚██╗██║██╔══╝  ██║     
 ███████║███████╗██║ ╚████║   ██║   ██║██║ ╚████║███████╗███████╗
 ╚══════╝╚══════╝╚═╝  ╚═══╝   ╚═╝   ╚═╝╚═╝  ╚═══╝╚══════╝╚══════╝
                     SentinelNet AI  v1.0
    """)

    threads = []

    # 1. Flask API (always start)
    t_flask = threading.Thread(target=start_flask, daemon=True, name="FlaskAPI")
    threads.append(t_flask)

    # 2. Packet sniffer (skip in NO_SNIFF mode)
    if not NO_SNIFF:
        t_sniffer = threading.Thread(target=start_sniffer, daemon=True, name="Sniffer")
        threads.append(t_sniffer)
        # 3. Detection loop (only meaningful when sniffer is running)
        t_detector = threading.Thread(target=start_detector, daemon=True, name="Detector")
        threads.append(t_detector)
    else:
        logger.warning("[Main] NO_SNIFF=1 — packet capture disabled.")

    for t in threads:
        t.start()
        logger.info(f"[Main] Thread started: {t.name}")

    # Keep main thread alive
    for t in threads:
        t.join()
