"""
utils.py - Shared Utility Functions
====================================
Common helpers used across the entire Python agent.
Keeps things DRY (Don't Repeat Yourself).
"""

import datetime
import json
import logging
import os

# ── Logging Setup ──────────────────────────────────────────────────────────
# Creates a logger that prints coloured timestamps to the console
LOG_FORMAT = "[%(asctime)s] %(levelname)s — %(message)s"
logging.basicConfig(level=logging.INFO, format=LOG_FORMAT, datefmt="%H:%M:%S")
logger = logging.getLogger("SentinelNet")


def get_timestamp() -> str:
    """Return current UTC time as an ISO-8601 string."""
    return datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")


def build_alert(threat_type: str, source_ip: str, dest_ip: str,
                protocol: str, packet_size: int, threat_level: str,
                details: str = "") -> dict:
    """
    Build a standardised alert dictionary.

    Parameters
    ----------
    threat_type   : e.g. "DDoS", "Port Scan", "Packet Flood"
    source_ip     : attacking / suspicious source address
    dest_ip       : target address
    protocol      : TCP / UDP / ICMP / Other
    packet_size   : byte count of the triggering packet
    threat_level  : "LOW" | "MEDIUM" | "HIGH" | "CRITICAL"
    details       : free-text description
    """
    return {
        "timestamp": get_timestamp(),
        "threat_type": threat_type,
        "source_ip": source_ip,
        "destination_ip": dest_ip,
        "protocol": protocol,
        "packet_size": packet_size,
        "threat_level": threat_level,
        "details": details,
    }


def save_alert_to_file(alert: dict, log_path: str = "logs/alerts.jsonl") -> None:
    """
    Append an alert as a JSON line to a local log file.
    Creates the directory and file if they don't exist.
    """
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    with open(log_path, "a") as f:
        f.write(json.dumps(alert) + "\n")
    logger.info(f"Alert saved → {log_path}")


def load_alerts_from_file(log_path: str = "logs/alerts.jsonl") -> list:
    """Read all saved alerts from the JSONL log file."""
    if not os.path.exists(log_path):
        return []
    alerts = []
    with open(log_path, "r") as f:
        for line in f:
            line = line.strip()
            if line:
                alerts.append(json.loads(line))
    return alerts


def protocol_name(proto_num: int) -> str:
    """Convert a numeric IP protocol number to a human-readable name."""
    mapping = {1: "ICMP", 6: "TCP", 17: "UDP"}
    return mapping.get(proto_num, "Other")
