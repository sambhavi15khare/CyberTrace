"""
detector.py — Detection Engine
================================
TEAM MEMBER 2 — owns this file.

Reads packets from the Sniffer's shared buffer and applies
rule-based heuristics to detect:

  1. DDoS-like traffic     — many packets from one IP in a short window
  2. Port Scanning         — one IP hitting many different destination ports
  3. Packet Flooding       — massive packet volume regardless of source
  4. Suspicious Frequency  — abnormally high request rate from one source

Detected threats are turned into alert dicts (via utils.build_alert)
and forwarded to the Flask API, which stores them in MySQL via Java backend.

HOW TO RUN (standalone test):
  python detector.py
  (uses simulated data — no root needed)
"""

import time
import threading
import requests
from collections import defaultdict

# Import from our own modules
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from utils.utils import build_alert, save_alert_to_file, logger

# ── Thresholds (tune these for your test environment) ─────────────────────
DDOS_THRESHOLD = 100          # packets from one IP within the time window
PORT_SCAN_THRESHOLD = 20      # unique destination ports from one source
FLOOD_THRESHOLD = 500         # total packets in the window (all sources)
FREQUENCY_WINDOW = 5          # seconds — rolling time window for all checks

# ── Flask API endpoint (running on localhost) ──────────────────────────────
FLASK_API_URL = "http://localhost:5000/alert"


# ── Internal state (reset each detection cycle) ───────────────────────────
class TrafficStats:
    """Keeps rolling counters for the current detection window."""

    def __init__(self):
        self.reset()

    def reset(self):
        # ip → count of packets seen
        self.ip_packet_count: dict = defaultdict(int)
        # ip → set of destination ports contacted
        self.ip_port_set: dict = defaultdict(set)
        # total packet count
        self.total_packets: int = 0
        # window start time
        self.window_start: float = time.time()

    def is_window_expired(self) -> bool:
        return (time.time() - self.window_start) >= FREQUENCY_WINDOW


_stats = TrafficStats()
_stats_lock = threading.Lock()


# ── Alert sender ─────────────────────────────────────────────────────────
def _send_alert(alert: dict) -> None:
    """
    Forward alert to the Flask API (non-blocking best-effort).
    Also saves to local file as a backup.
    """
    save_alert_to_file(alert)           # always save locally
    try:
        resp = requests.post(FLASK_API_URL, json=alert, timeout=2)
        if resp.status_code == 201:
            logger.info(f"[Detector] Alert sent → {alert['threat_type']} from {alert['source_ip']}")
        else:
            logger.warning(f"[Detector] API returned {resp.status_code}")
    except requests.exceptions.ConnectionError:
        logger.warning("[Detector] Flask API unreachable — alert saved locally only.")


# ── Detection rules ──────────────────────────────────────────────────────

def _check_ddos(ip: str, count: int) -> dict | None:
    """Rule 1: single IP flooding with many packets."""
    if count >= DDOS_THRESHOLD:
        return build_alert(
            threat_type="DDoS",
            source_ip=ip,
            dest_ip="*",
            protocol="Multiple",
            packet_size=0,
            threat_level="CRITICAL",
            details=f"IP {ip} sent {count} packets in {FREQUENCY_WINDOW}s",
        )
    return None


def _check_port_scan(ip: str, ports: set) -> dict | None:
    """Rule 2: one IP probing many ports (port scan)."""
    if len(ports) >= PORT_SCAN_THRESHOLD:
        return build_alert(
            threat_type="Port Scan",
            source_ip=ip,
            dest_ip="*",
            protocol="TCP",
            packet_size=0,
            threat_level="HIGH",
            details=f"IP {ip} scanned {len(ports)} ports: {sorted(ports)[:10]}…",
        )
    return None


def _check_flood(total: int) -> dict | None:
    """Rule 3: overall packet volume too high."""
    if total >= FLOOD_THRESHOLD:
        return build_alert(
            threat_type="Packet Flood",
            source_ip="Multiple",
            dest_ip="*",
            protocol="Multiple",
            packet_size=0,
            threat_level="HIGH",
            details=f"Total {total} packets observed in {FREQUENCY_WINDOW}s",
        )
    return None


# ── Main analysis function ───────────────────────────────────────────────

def analyze_packets(packets: list) -> list:
    """
    Ingest a list of packet dicts (from sniffer.get_recent_packets()).
    Update rolling stats and return a list of alerts generated this cycle.
    """
    global _stats

    alerts = []

    with _stats_lock:
        # Reset stats if the time window has rolled over
        if _stats.is_window_expired():
            _stats.reset()

        # Tally each packet
        for pkt in packets:
            src = pkt.get("src_ip", "0.0.0.0")
            dst_port = pkt.get("dst_port", 0)
            _stats.ip_packet_count[src] += 1
            _stats.ip_port_set[src].add(dst_port)
            _stats.total_packets += 1

        # Evaluate rules against accumulated stats
        for ip, count in _stats.ip_packet_count.items():
            alert = _check_ddos(ip, count)
            if alert:
                alerts.append(alert)

            alert = _check_port_scan(ip, _stats.ip_port_set[ip])
            if alert:
                alerts.append(alert)

        alert = _check_flood(_stats.total_packets)
        if alert:
            alerts.append(alert)

    # Send every alert
    for a in alerts:
        _send_alert(a)

    return alerts


# ── Background detection loop ─────────────────────────────────────────────

def start_detection_loop(get_packets_fn, interval: float = 2.0) -> None:
    """
    Continuously fetch packets from `get_packets_fn` and run analysis.

    Parameters
    ----------
    get_packets_fn : callable — e.g. sniffer.get_recent_packets
    interval       : seconds between detection cycles
    """
    logger.info("[Detector] Detection loop started.")
    while True:
        packets = get_packets_fn()
        if packets:
            found = analyze_packets(packets)
            if found:
                logger.warning(f"[Detector] {len(found)} threat(s) detected this cycle!")
        time.sleep(interval)


# ── Standalone test with simulated data ──────────────────────────────────
if __name__ == "__main__":
    print("=== SentinelNet Detector — Simulation Test ===\n")

    # Simulate 150 packets from one IP (should trigger DDoS)
    fake_packets = [
        {
            "src_ip": "192.168.1.100",
            "dst_ip": "10.0.0.1",
            "protocol": "TCP",
            "dst_port": 80 + (i % 5),
            "packet_size": 512,
            "timestamp": time.time(),
        }
        for i in range(150)
    ]

    # Simulate port scan (50 different ports from one IP)
    fake_packets += [
        {
            "src_ip": "10.0.0.99",
            "dst_ip": "10.0.0.1",
            "protocol": "TCP",
            "dst_port": 1000 + i,
            "packet_size": 64,
            "timestamp": time.time(),
        }
        for i in range(50)
    ]

    alerts = analyze_packets(fake_packets)
    print(f"\n{len(alerts)} alert(s) generated:\n")
    for a in alerts:
        print(f"  [{a['threat_level']}] {a['threat_type']} — {a['details']}")
