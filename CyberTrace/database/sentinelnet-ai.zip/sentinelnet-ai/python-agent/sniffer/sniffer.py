"""
sniffer.py — Packet Sniffer Module
=====================================
TEAM MEMBER 1 — owns this file.

Uses Scapy to capture live network packets and extract key fields:
  • source IP        • destination IP
  • protocol         • packet size
  • timestamp

Captured packets are stored in a shared in-memory list that the
Detection Engine reads in real time.

HOW TO RUN (standalone test):
  sudo python sniffer.py
  (root / admin privileges required for raw-socket capture)
"""

import threading
import time
from collections import deque

from scapy.all import sniff, IP, TCP, UDP, ICMP

# ── Shared packet buffer (thread-safe deque) ───────────────────────────────
# maxlen prevents unbounded memory growth; adjust for your machine.
PACKET_BUFFER: deque = deque(maxlen=5000)

# Lock so the detector thread can read safely while the sniffer writes
_buffer_lock = threading.Lock()


def _parse_packet(pkt) -> dict | None:
    """
    Internal callback: extract fields from a raw Scapy packet.
    Returns a dict or None if the packet has no IP layer.
    """
    if not pkt.haslayer(IP):
        return None          # skip non-IP frames (ARP, etc.)

    ip_layer = pkt[IP]

    # Determine transport-layer protocol
    if pkt.haslayer(TCP):
        proto = "TCP"
        sport = pkt[TCP].sport
        dport = pkt[TCP].dport
        flags = str(pkt[TCP].flags)
    elif pkt.haslayer(UDP):
        proto = "UDP"
        sport = pkt[UDP].sport
        dport = pkt[UDP].dport
        flags = ""
    elif pkt.haslayer(ICMP):
        proto = "ICMP"
        sport = 0
        dport = 0
        flags = ""
    else:
        proto = "Other"
        sport = 0
        dport = 0
        flags = ""

    return {
        "timestamp": time.time(),            # Unix epoch float
        "src_ip": ip_layer.src,
        "dst_ip": ip_layer.dst,
        "protocol": proto,
        "src_port": sport,
        "dst_port": dport,
        "packet_size": len(pkt),             # total bytes
        "flags": flags,                       # TCP flags, e.g. "S", "SA"
    }


def _packet_callback(pkt) -> None:
    """Scapy calls this for every captured frame."""
    parsed = _parse_packet(pkt)
    if parsed:
        with _buffer_lock:
            PACKET_BUFFER.append(parsed)


def get_recent_packets(n: int = 200) -> list:
    """
    Return the last `n` captured packets (thread-safe copy).
    Called by the Detection Engine.
    """
    with _buffer_lock:
        data = list(PACKET_BUFFER)
    return data[-n:]


def start_sniffing(interface: str = None, packet_count: int = 0) -> None:
    """
    Start capturing packets.

    Parameters
    ----------
    interface    : NIC name e.g. "eth0", "Wi-Fi". None = Scapy auto-selects.
    packet_count : 0 = capture forever until Ctrl+C.

    This function BLOCKS — run it in a background thread from main.py.
    """
    print(f"[Sniffer] Starting capture on interface: {interface or 'auto'}")
    print("[Sniffer] Press Ctrl+C to stop.\n")

    sniff(
        iface=interface,
        prn=_packet_callback,      # callback per packet
        store=False,               # don't keep raw packets in Scapy memory
        count=packet_count,        # 0 = infinite
    )


# ── Standalone test ─────────────────────────────────────────────────────────
if __name__ == "__main__":
    # When run directly: capture 20 packets and print them
    print("=== SentinelNet Sniffer — Quick Test (20 packets) ===")

    def _test_callback(pkt):
        data = _parse_packet(pkt)
        if data:
            print(data)

    sniff(prn=_test_callback, store=False, count=20)
